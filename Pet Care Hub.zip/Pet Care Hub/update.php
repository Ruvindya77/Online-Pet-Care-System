d='$breed', p_name='$p_name', o_name='$o_name', number='$number' WHERE id=$id";


    if (mysqli_query($conn,$sql)) 
      {
        //echo "updated successfully";
        //header('location:display.php');
      }
    else 
      {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
      }

    // Close the connection

    mysqli_close($conn);
   }  
?>
 <?php
// Check if the form is submitted
include 'connect.php';
$id=$_GET['updatenumber'];

if ($_SERVER["REQUEST_METHOD"] == "POST")
{
  // Get form data

  $date = $_POST["date"];
  $breed = $_POST["breed"];
  $p_name = $_POST["p_name"];
  $o_name = $_POST["o_name"];
  $number = $_POST["number"];
  


$servername="localhost";
$username="root";
$password="";
$dbname="pet_care_hub";

$conn=mysqli_connect($servername, $username, $password, $dbname);

if (!$conn)
{ 
die("Connection failed:" . mysqli_connect_error());
}

 // Insert data into the database

 $sql = "UPDATE appointment SET date='$date', bree
<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard | PetCareHub</title>
    <link rel="stylesheet" href="CSS/Header.css">
    <link rel="stylesheet" href="CSS/Footer.css">
    <link rel="stylesheet" href="appointment.css">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Play&display=swap" rel="stylesheet"> 
    
</head>
<body class="body">
    <div id="header">
        <table id="head">
          <tr>
            <th><img id="logo" src="Images/LOGO.jpg"></th>
            <th>
                <p class="brand">Pet Care Hub (PVT)LTD</p>
            </th>
            <th>
              <button class="profile"><img src="Images/profile photo.jpg" class="profilePic"></button>
            </th>
          </tr>
        </table> 
    </div>
    <table id="tabs">
        <td><a id="btn" href="homePage.html">HOME</a></td>
        <td><a id="btn" href="">CUSTOMER CARE</a></td>
        <td><a id="btn" href="">SIGN UP</a></td>
        <td><a id="btn" href="">ABOUT US</a></td>
    </table>
   <head>
    <meta charset="UTF-8">
     
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veterinary Appointments</title>
    
   
</head>
<body>
     

<header>
        <h1>Appointment</h1>
</header>
<main>
        <form class="appointment-form" method="POST" action="" >
            <div class="form-group">
                <label for="date">Appointment Date</label>
                <input type="date" id="date" name="date" required>
            </div>
            <div class="form-group">
                <label for="breed">Pet Breed</label>
                <input type="text" id="breed" name="breed" required>
            </div>
            
            <div class="form-group">
                <label for="p_name">Pet Name</label>
                <input type="text" id="p_name" name="p_name" required>
            </div>
            <div class="form-group">
                <label for="o_name">Owner Name</label>
                <input type="text" id="o_name" name="o_name" required>
            </div>
            <div class="form-group">
                <label for="number">Phone Number</label>
                <input type="tel" id="number" name="number" required>
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Update</button>

      
        </form>
      </main>

      <!--Footer-->

<footer class="footer">
    <div class="container">
     <div class="row">
       <div class="footer-col">
         <h4>About</h4>
         <ul>
           <li><a href="#">Website</a></li>
           <li><a href="#">Team</a></li>
           <li><a href="#">Careers</a></li>
         </ul>
       </div>
       <div class="footer-col">
        <h4>Services</h4>
        <ul>
          <li><a href="#">Veterinary Care</a></li>
          <li><a href="#">Pet Nutrition Counseling</a></li>
          <li><a href="#">Pet Adoption Services</a></li>
        </ul>
      </div>
       <div class="footer-col">
         <h4>Pet Care Hub</h4>
         <ul>
           <p>Connect with Us for All Your Pet Needs: Discover a world of love and care for your furry friends at Pet Care Hub. Our dedicated team is committed to providing top-notch pet care solutions. Stay updated with the latest in pet care, health tips, and news. Join our community of pet lovers today!</p>
         </ul>
       </div>
       <div class="footer-col">
         <h4>follow us</h4>
         <div class="social-links">
           <a href="#"><input type="image" src="Images/facebook.png" class="socialMedia"></a>
           <a href="#"><input type="image" src="Images/twitter.png" class="socialMedia1"></a>
           <a href="#"><input type="image" src="Images/instagram.png" class="socialMedia"></a>
           <a href="#"><input type="image" src="Images/linkedin.png" class="socialMedia"></a>
         </div>
       </div>
     </div>
    </div>
 </footer>
</body>
</html>