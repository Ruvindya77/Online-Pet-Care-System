<?php
include 'connect.php';
if(isset($GET['deletenumber'])){
    $number=$_GET['deletenumber'];


    $sql="delete from 'appointment' where number=$number";
    $result=mysqli_query($con,$sql);
    if($result){
        header('location:display.php');
    }else{
        echo "DB NOT CONNECTED";

    }


}




?>