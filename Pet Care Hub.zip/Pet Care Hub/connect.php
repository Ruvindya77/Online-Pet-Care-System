<?php
$host="localhost";
$user="root";
$pass="";
$db="pet_care_hub";

$con=mysqli_connect($host,$user,$pass,$db);


if(!$con){
    echo "DB NOT CONNECTED";
}

?>