<?php
include 'connect.php'; ?>


<!--Header-->
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard | PetCareHub</title>
    <link rel="stylesheet" href="CSS/Header.css">
    <link rel="stylesheet" href="CSS/Footer.css">
    <link rel="stylesheet" href="appointment.css">
    <link href="https://fonts.googleapis.com/css2?family=Fredoka+One&family=Play&display=swap" rel="stylesheet"> 
    
</head>
<body class="body">
    <div id="header">
        <table id="head">
          <tr>
            <th><img id="logo" src="Images/LOGO.jpg"></th>
            <th>
                <p class="brand">Pet Care Hub (PVT)LTD</p>
            </th>
            <th>
              <button class="profile"><img src="Images/profile photo.jpg" class="profilePic"></button>
            </th>
          </tr>
        </table> 
    </div>
    <table id="tabs">
        <td><a id="btn" href="homePage.html">HOME</a></td>
        <td><a id="btn" href="">CUSTOMER CARE</a></td>
        <td><a id="btn" href="">SIGN UP</a></td>
        <td><a id="btn" href="">ABOUT US</a></td>
    </table>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment</title>
    <link rel="stylesheet" href="appointment.css">
</head>
<body>
<br>
<div class="container">
<button class="btn btn-primary my-5"><a href="appointment.php" class="text-light">Add user</a>
</button>
<table class="table" border=2px cellpadding= 100px cellspacing=20px>
    <thead>
    <tr>
      <th scope="col" class="column"> Appointment Date</th>
      <th scope="col" class="column"> Pet Breed</th>
      <th scope="col" class="column"> Pet Name</th>
      <th scope="col" class="column"> Owner Name</th>
      <th scope="col" class="column"> Phone Number</th>
      <th scope="col"> Actions</th>
    </tr>
    
</thead>
  <tbody>

  <?php
$sql ="select * from `appointment`";
$result = mysqli_query($con, $sql);

if ($result) {
  while($row = mysqli_fetch_assoc($result)){
    $date=$row['date'];
    $breed=$row['breed'];
    $p_name=$row['p_name'];
    $o_name=$row['o_name'];
    $number=$row['number'];
    echo ' <tr>
    <th scope="row">'.$date.'</th>
    <td>'.$breed.'</td>
    <td>'.$p_name.'</td>
    <td>'.$o_name.'</td>
    <td>'.$number.'</td>
    <td>
    <button class="btn btn-primary"><a href="update.php?updatenumber=' .$number.'" class="text-light">Update</a></button>
    <button class="btn btn-danger"><a href="delete.php?deletenumber='.$number.'" class="text-light">Delete</a></button>
    </td>

  </tr>';

  }
       
}

?>



  
  </tbody>
</table>
</div>

   
      <!--Footer-->

<footer class="footer">
    <div class="container">
     <div class="row">
       <div class="footer-col">
         <h4>About</h4>
         <ul>
           <li><a href="#">Website</a></li>
           <li><a href="#">Team</a></li>
           <li><a href="#">Careers</a></li>
         </ul>
       </div>
       <div class="footer-col">
        <h4>Services</h4>
        <ul>
          <li><a href="#">Veterinary Care</a></li>
          <li><a href="#">Pet Nutrition Counseling</a></li>
          <li><a href="#">Pet Adoption Services</a></li>
        </ul>
      </div>
       <div class="footer-col">
         <h4>Pet Care Hub</h4>
         <ul>
           <p>Connect with Us for All Your Pet Needs: Discover a world of love and care for your furry friends at Pet Care Hub. Our dedicated team is committed to providing top-notch pet care solutions. Stay updated with the latest in pet care, health tips, and news. Join our community of pet lovers today!</p>
         </ul>
       </div>
       <div class="footer-col">
         <h4>follow us</h4>
         <div class="social-links">
           <a href="#"><input type="image" src="Images/facebook.png" class="socialMedia"></a>
           <a href="#"><input type="image" src="Images/twitter.png" class="socialMedia1"></a>
           <a href="#"><input type="image" src="Images/instagram.png" class="socialMedia"></a>
           <a href="#"><input type="image" src="Images/linkedin.png" class="socialMedia"></a>
         </div>
       </div>
     </div>
    </div>
 </footer> 
</body>
</html>